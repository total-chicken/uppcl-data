"""
UPPCL Local Data Server — Multi-Tenant Edition
Runs on port 7321. Requires VPN connection to ftp.uppclonline.com.

Setup: pip install flask flask-cors requests
Run:   python local_server.py   (or double-click run_server.bat)

Endpoints:
  GET  /ping       — health check
  GET  /status     — sync log + running flag
  POST /discover   — scan FTP, register division codes in manifest.json
  POST /sync       — download, remap, chunk, upload to GitHub
"""

import os
import io
import csv
import gzip
import json
import base64
import threading
from datetime import datetime, timedelta
from ftplib import FTP, error_perm

import requests
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# ─── LOCAL CONFIG (credentials stay on your machine, never in the repo) ──────
_DIR = os.path.dirname(os.path.abspath(__file__))

def load_config():
    cfg_path = os.path.join(_DIR, 'config.json')
    if os.path.exists(cfg_path):
        with open(cfg_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

CONFIG = load_config()

# ─── GITHUB SETTINGS ─────────────────────────────────────────────────────────
_gh = CONFIG.get('github', {})
GH_OWNER  = _gh.get('owner', 'total-chicken')
GH_REPO   = _gh.get('repo',  'uppcl-data')
GH_BRANCH = _gh.get('branch','main')
RAW_BASE  = f'https://raw.githubusercontent.com/{GH_OWNER}/{GH_REPO}/main/'

# ─── FTP FOLDERS ─────────────────────────────────────────────────────────────
FTP_MASTER   = '01-MASTER_DATA'
FTP_BILLED   = '03_CSV_BILLED'
FTP_UNBILLED = '04_CSV_UNBILLED'

CSV_COLS = [
    'ACCT_ID', 'MOBILE_NO', 'NAME', 'ADDRESS', 'CATEGORY', 'LOAD',
    'LAT', 'LON', 'SUBSTATION', 'FEEDER', 'LP DATE', 'LP AMT', 'TOTAL OUTSTANDING'
]
MAX_BYTES = 5 * 1024 * 1024  # 5 MB per chunk

# ─── GLOBALS ─────────────────────────────────────────────────────────────────
SYNC_LOG   = []
IS_RUNNING = False


def log(msg):
    global SYNC_LOG
    t = datetime.now().strftime('%H:%M:%S')
    m = f"[{t}] {msg}"
    print(m, flush=True)
    SYNC_LOG.append(m)
    if len(SYNC_LOG) > 500:
        SYNC_LOG.pop(0)


# ─── GITHUB HELPERS ──────────────────────────────────────────────────────────
def _gh_headers(pat):
    return {'Authorization': f'token {pat}', 'Accept': 'application/vnd.github+json'}


def gh_get_json(path):
    url = f'https://raw.githubusercontent.com/{GH_OWNER}/{GH_REPO}/main/{path}'
    r = requests.get(url, timeout=15)
    if r.status_code == 200:
        return r.json()
    return None


def gh_put(path, content_str, pat, message='FTP sync'):
    url = f'https://api.github.com/repos/{GH_OWNER}/{GH_REPO}/contents/{path}'
    headers = _gh_headers(pat)
    sha = None
    r = requests.get(url, headers=headers, timeout=15)
    if r.status_code == 200:
        sha = r.json().get('sha')
    body = {
        'message': message,
        'content': base64.b64encode(content_str.encode('utf-8')).decode('ascii'),
        'branch':  GH_BRANCH
    }
    if sha:
        body['sha'] = sha
    r = requests.put(url, headers=headers, json=body, timeout=60)
    if r.status_code not in (200, 201):
        raise RuntimeError(f"GitHub {r.status_code}: {r.text[:200]}")
    return r.json()


def fetch_discoms():
    # Local config takes priority (credentials stay private)
    local = CONFIG.get('discoms', [])
    if local:
        return local
    # Fallback: public discoms.json on GitHub (no passwords there)
    d = gh_get_json('discoms.json')
    return d if d else []


def fetch_manifest():
    m = gh_get_json('manifest.json')
    if not m:
        m = {'DV': {}, 'MV': {}, 'PV': {}, 'PU': {}}
    return m


# ─── FTP HELPERS ─────────────────────────────────────────────────────────────
def ftp_connect(d):
    ftp = FTP()
    ftp.connect(d.get('ftpServer', 'ftp.uppclonline.com'), int(d.get('ftpPort', 21)), timeout=60)
    ftp.login(user=d['ftpUser'], passwd=d['ftpPass'])
    return ftp


def ftp_list(ftp, path):
    try:
        entries = ftp.nlst(path)
        return [e.split('/')[-1] for e in entries if e]
    except error_perm:
        return []


def ftp_download_gz(ftp, remote_path):
    buf = io.BytesIO()
    ftp.retrbinary('RETR ' + remote_path, buf.write)
    buf.seek(0)
    return gzip.decompress(buf.read())


def find_master_file(ftp, code_num):
    month_dirs = ftp_list(ftp, FTP_MASTER)
    month_dirs = [d for d in month_dirs if d and '_' in d]
    if not month_dirs:
        raise FileNotFoundError(f'No month folders in {FTP_MASTER}')
    latest = sorted(month_dirs)[-1]
    folder = f'{FTP_MASTER}/{latest}'
    files = ftp_list(ftp, folder)
    for fname in files:
        if f'DIV{code_num}_' in fname.upper() and fname.upper().endswith('.CSV.GZ'):
            return f'{folder}/{fname}', latest
    raise FileNotFoundError(f'No master file for DIV{code_num} in {folder}')


def find_daily_file(ftp, base_folder, prefix, code_num):
    now = datetime.utcnow()
    for delta in (0, 1):
        d = now - timedelta(days=delta)
        ddmmyyyy = d.strftime('%d%m%Y')
        folder = f'{base_folder}/{ddmmyyyy}'
        files = ftp_list(ftp, folder)
        for fname in files:
            if (fname.upper().startswith(prefix.upper())
                    and f'DIV{code_num}_' in fname.upper()
                    and fname.upper().endswith('.CSV.GZ')):
                return f'{folder}/{fname}', ddmmyyyy
    raise FileNotFoundError(f'No {prefix}*DIV{code_num}* file in {base_folder} (today/yesterday)')


# ─── DATA PROCESSING ─────────────────────────────────────────────────────────
def _find_col(hdrs, options):
    for opt in options:
        try:
            return hdrs.index(opt.upper())
        except ValueError:
            continue
    return -1


def _csv_escape(v):
    v = str(v) if v is not None else ''
    if any(c in v for c in (',', '"', '\n')):
        v = '"' + v.replace('"', '""') + '"'
    return v


def shard_master(rows, discom_id, div_code):
    if not rows:
        return []
    keys = list(rows[0].keys())
    hdrs = [k.strip().upper() for k in keys]

    i_acct = _find_col(hdrs, ['ACCT_ID', 'ACCOUNT_ID'])
    i_mob  = _find_col(hdrs, ['MOBILE_NO', 'MOBILE'])
    i_name = _find_col(hdrs, ['NAME', 'CONSUMER_NAME'])
    i_addr = _find_col(hdrs, ['ADDRESS', 'ADDRES'])
    i_cat  = _find_col(hdrs, ['CATEGORY', 'TARIFF_TYPE', 'SUPPLY_TYPE', 'TARIFF'])
    i_load = _find_col(hdrs, ['LOAD', 'SANCTION_LOAD', 'SANCT_LOAD'])
    i_lat  = _find_col(hdrs, ['LAT', 'LATITUDE'])
    i_lon  = _find_col(hdrs, ['LON', 'LONGITUDE', 'LONG'])
    i_sub  = _find_col(hdrs, ['SUBSTATION', 'SUB_STATION'])
    i_feed = _find_col(hdrs, ['FEEDER'])
    i_date = _find_col(hdrs, ['PAY_DATE', 'LP DATE', 'LAST_PAY_DATE'])
    i_amt  = _find_col(hdrs, ['PAY_AMT', 'LP AMT', 'LAST_PAY_AMT'])
    i_out  = _find_col(hdrs, ['TOTAL_OUTSTANDING', 'TOTAL OUTSTANDING', 'AMOUNT_PAYABLE'])

    header_line = ','.join(CSV_COLS) + '\n'
    files = []
    chunk_lines = []
    chunk_size  = len(header_line)
    letter      = 0

    def flush():
        nonlocal chunk_lines, chunk_size, letter
        if not chunk_lines:
            return
        fname   = f'{discom_id}/{div_code}/master/chunk_{chr(97 + letter)}.csv'
        content = header_line + ''.join(chunk_lines)
        files.append((fname, content))
        letter += 1
        chunk_lines, chunk_size = [], len(header_line)

    for r in rows:
        vals = [r.get(k, '') for k in keys]
        lat = vals[i_lat] if i_lat >= 0 else ''
        lon = vals[i_lon] if i_lon >= 0 else ''
        try:
            if float(lat) > 50:
                lat, lon = lon, lat
        except (TypeError, ValueError):
            pass

        mapped = {
            'ACCT_ID':           vals[i_acct] if i_acct >= 0 else '',
            'MOBILE_NO':         vals[i_mob]  if i_mob  >= 0 else '',
            'NAME':              vals[i_name] if i_name >= 0 else '',
            'ADDRESS':           vals[i_addr] if i_addr >= 0 else '',
            'CATEGORY':          vals[i_cat]  if i_cat  >= 0 else '',
            'LOAD':              vals[i_load] if i_load >= 0 else '',
            'LAT':               lat,
            'LON':               lon,
            'SUBSTATION':        vals[i_sub]  if i_sub  >= 0 else '',
            'FEEDER':            vals[i_feed] if i_feed >= 0 else '',
            'LP DATE':           vals[i_date] if i_date >= 0 else '',
            'LP AMT':            vals[i_amt]  if i_amt  >= 0 else '',
            'TOTAL OUTSTANDING': vals[i_out]  if i_out  >= 0 else '',
        }
        line = ','.join(_csv_escape(mapped[c]) for c in CSV_COLS) + '\n'
        if chunk_size + len(line) > MAX_BYTES:
            flush()
        chunk_lines.append(line)
        chunk_size += len(line)
    flush()
    return files


def chunk_passthrough(raw_bytes, discom_id, div_code, f_type):
    text  = raw_bytes.decode('utf-8', errors='replace')
    lines = text.splitlines(keepends=True)
    if not lines:
        return []
    header = lines[0]
    files  = []
    chunk_lines = []
    chunk_size  = len(header)
    letter      = 0

    def flush():
        nonlocal chunk_lines, chunk_size, letter
        if not chunk_lines:
            return
        fname   = f'{discom_id}/{div_code}/{f_type}/chunk_{chr(97 + letter)}.csv'
        content = header + ''.join(chunk_lines)
        files.append((fname, content))
        letter += 1
        chunk_lines, chunk_size = [], len(header)

    for line in lines[1:]:
        if chunk_size + len(line) > MAX_BYTES:
            flush()
        chunk_lines.append(line)
        chunk_size += len(line)
    flush()
    return files


# ─── DISCOVERY ───────────────────────────────────────────────────────────────
def run_discovery(pat):
    global IS_RUNNING
    IS_RUNNING = True
    try:
        log('Starting Division Discovery across all DISCOMs...')
        discoms  = fetch_discoms()
        manifest = fetch_manifest()

        for d in discoms:
            d_id = d['id']
            if not isinstance(manifest.get(d_id), dict):
                manifest[d_id] = {}
            if 'ftpPass' not in d:
                log(f'  Skipping {d_id}: no FTP credentials in config.json')
                continue
            try:
                log(f"  [{d_id}] Connecting as {d['ftpUser']}...")
                ftp = ftp_connect(d)
                month_dirs = ftp_list(ftp, FTP_MASTER)
                month_dirs = [x for x in month_dirs if x and '_' in x]
                if not month_dirs:
                    log(f'  [{d_id}] No month folders found')
                    ftp.quit()
                    continue
                latest = sorted(month_dirs)[-1]
                log(f'  [{d_id}] Scanning {FTP_MASTER}/{latest}...')
                files = ftp_list(ftp, f'{FTP_MASTER}/{latest}')
                found = 0
                for fname in files:
                    if not fname.upper().endswith('.CSV.GZ'):
                        continue
                    parts = fname.split('_')
                    if len(parts) < 2 or not parts[1].upper().startswith('DIV'):
                        continue
                    div_code = parts[1].upper()
                    if div_code not in manifest[d_id]:
                        manifest[d_id][div_code] = {'master': [], 'billed': [], 'unbilled': []}
                        log(f'    + {d_id}/{div_code}')
                        found += 1
                    else:
                        log(f'    = {d_id}/{div_code} (already known)')
                if not found:
                    log(f'  [{d_id}] No new divisions found')
                ftp.quit()
            except Exception as e:
                log(f'  [{d_id}] Error: {e}')

        manifest['updated'] = datetime.utcnow().isoformat() + 'Z'
        log('Uploading manifest.json to GitHub...')
        gh_put('manifest.json', json.dumps(manifest, indent=2), pat, 'Discovery: register divisions')
        log('✓ Discovery complete.')
    except Exception as e:
        log(f'CRITICAL: {e}')
    finally:
        IS_RUNNING = False


# ─── SYNC ────────────────────────────────────────────────────────────────────
def run_sync(types, pat, target_discom=None, target_division=None):
    global IS_RUNNING
    IS_RUNNING = True
    try:
        log(f"Sync | types={types} | discom={target_discom} | div={target_division}")
        discoms  = fetch_discoms()
        manifest = fetch_manifest()
        uploads  = []

        for d in discoms:
            if target_discom and d['id'] != target_discom:
                continue
            d_id = d['id']
            if 'ftpPass' not in d:
                log(f'Skipping {d_id}: no FTP credentials in config.json')
                continue
            if not isinstance(manifest.get(d_id), dict):
                manifest[d_id] = {}

            divs = [target_division] if target_division else list(manifest[d_id].keys())
            if not divs:
                log(f'No divisions for {d_id} — run Discovery first')
                continue

            try:
                log(f"[{d_id}] Connecting as {d['ftpUser']}...")
                ftp = ftp_connect(d)

                for div_code in divs:
                    code_num = div_code.upper().replace('DIV', '')
                    if div_code not in manifest[d_id]:
                        manifest[d_id][div_code] = {'master': [], 'billed': [], 'unbilled': []}
                    entry = manifest[d_id][div_code]

                    if 'master' in types:
                        try:
                            ftp_path, month_dir = find_master_file(ftp, code_num)
                            log(f'  [{d_id}/{div_code}] Downloading master...')
                            raw  = ftp_download_gz(ftp, ftp_path)
                            rows = list(csv.DictReader(io.StringIO(raw.decode('utf-8', 'replace'))))
                            log(f'  master: {len(rows)} rows')
                            files = shard_master(rows, d_id, div_code)
                            uploads.extend(files)
                            entry['master'] = [f for f, _ in files]
                            entry.setdefault('sync_status', {})['master_period'] = month_dir
                            log(f'  master → {len(files)} chunk(s)')
                        except FileNotFoundError as e:
                            log(f'  master skipped: {e}')

                    if 'billed' in types:
                        try:
                            ftp_path, ddmmyyyy = find_daily_file(ftp, FTP_BILLED, 'BILLED_', code_num)
                            log(f'  [{d_id}/{div_code}] Downloading billed...')
                            raw   = ftp_download_gz(ftp, ftp_path)
                            files = chunk_passthrough(raw, d_id, div_code, 'billed')
                            uploads.extend(files)
                            entry['billed'] = [f for f, _ in files]
                            entry.setdefault('sync_status', {})['billed_date'] = ddmmyyyy
                            log(f'  billed → {len(files)} chunk(s)')
                        except FileNotFoundError as e:
                            log(f'  billed skipped: {e}')

                    if 'unbilled' in types:
                        try:
                            ftp_path, ddmmyyyy = find_daily_file(ftp, FTP_UNBILLED, 'UNBILLED_', code_num)
                            log(f'  [{d_id}/{div_code}] Downloading unbilled...')
                            raw   = ftp_download_gz(ftp, ftp_path)
                            files = chunk_passthrough(raw, d_id, div_code, 'unbilled')
                            uploads.extend(files)
                            entry['unbilled'] = [f for f, _ in files]
                            entry.setdefault('sync_status', {})['unbilled_date'] = ddmmyyyy
                            log(f'  unbilled → {len(files)} chunk(s)')
                        except FileNotFoundError as e:
                            log(f'  unbilled skipped: {e}')

                    entry['updated'] = datetime.utcnow().isoformat() + 'Z'
                    log(f'  [{d_id}/{div_code}] Done')

                ftp.quit()
            except Exception as e:
                log(f'[{d_id}] Error: {e}')

        if not uploads:
            log('Nothing to upload.')
            return

        manifest['updated'] = datetime.utcnow().isoformat() + 'Z'
        uploads.append(('manifest.json', json.dumps(manifest, indent=2)))
        log(f'Uploading {len(uploads)} file(s) to GitHub...')
        for path, content in uploads:
            log(f'  → {path}')
            gh_put(path, content, pat, f'FTP sync: {path}')
        log('✓ DONE. All files uploaded.')
    except Exception as e:
        log(f'CRITICAL: {e}')
    finally:
        IS_RUNNING = False


# ─── ENDPOINTS ───────────────────────────────────────────────────────────────
@app.route('/ping')
def ping():
    return jsonify({'ok': True})


@app.route('/status')
def status():
    return jsonify({'running': IS_RUNNING, 'log': SYNC_LOG})


@app.route('/discover', methods=['POST'])
def discover():
    if IS_RUNNING:
        return jsonify({'ok': False, 'message': 'Already running'})
    data = request.json or {}
    pat  = data.get('pat')
    if not pat:
        return jsonify({'ok': False, 'message': 'GitHub PAT required'})
    threading.Thread(target=run_discovery, args=(pat,), daemon=True).start()
    return jsonify({'ok': True, 'message': 'Discovery started'})


@app.route('/sync', methods=['POST'])
def sync():
    if IS_RUNNING:
        return jsonify({'ok': False, 'message': 'Sync already in progress'})
    data = request.json or {}
    pat  = data.get('pat')
    if not pat:
        return jsonify({'ok': False, 'message': 'GitHub PAT required'})
    threading.Thread(
        target=run_sync,
        kwargs={
            'types':           data.get('types', ['master', 'billed', 'unbilled']),
            'pat':             pat,
            'target_discom':   data.get('discom'),
            'target_division': data.get('division'),
        },
        daemon=True
    ).start()
    return jsonify({'ok': True, 'message': 'Sync started'})


if __name__ == '__main__':
    log('=' * 50)
    log('UPPCL Local Server  —  port 7321')
    log('Keep this window open while using the web app.')
    log('Press Ctrl+C to stop.')
    log('=' * 50)
    if not CONFIG.get('discoms'):
        log('WARNING: config.json not found or has no discoms — FTP operations will fail.')
        log('         Copy config.json into the same folder as local_server.py.')
    app.run(host='127.0.0.1', port=7321, debug=False)
