"""
UPPCL Local Data Server — Multi-Tenant Edition
Runs on port 7321. Requires VPN connection to ftp.uppclonline.com.

Setup: pip install flask flask-cors requests
Run:   python local_server.py   (or double-click run_server.bat)

Endpoints:
  GET  /ping       — health check
  GET  /status     — sync log + running flag
  POST /discover   — scan FTP, register division codes in manifest.json
  POST /sync       — download, remap, chunk, upload to GitHub
"""

import os
import io
import re
import csv
import gzip
import json
import base64
import threading
from datetime import datetime, timedelta
from ftplib import FTP, error_perm

import requests
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# ─── LOCAL CONFIG (credentials stay on your machine, never in the repo) ──────
_DIR = os.path.dirname(os.path.abspath(__file__))

def load_config():
    cfg_path = os.path.join(_DIR, 'config.json')
    if os.path.exists(cfg_path):
        with open(cfg_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

CONFIG = load_config()

# ─── GITHUB SETTINGS ─────────────────────────────────────────────────────────
_gh = CONFIG.get('github', {})
GH_OWNER  = _gh.get('owner', 'total-chicken')
GH_REPO   = _gh.get('repo',  'uppcl-data')
GH_BRANCH = _gh.get('branch','main')
RAW_BASE  = f'https://raw.githubusercontent.com/{GH_OWNER}/{GH_REPO}/main/'

# ─── FTP FOLDERS ─────────────────────────────────────────────────────────────
FTP_MASTER   = '01-MASTER_DATA'
FTP_BILLED   = '03_CSV_BILLED'
FTP_UNBILLED = '04_CSV_UNBILLED'

CSV_COLS = [
    'ACCT_ID', 'SDO_CODE', 'NAME', 'FATHER_NAME', 'ADDRESS', 'SUPPLY_TYPE',
    'LOAD', 'LOAD_UNIT', 'CON_STATUS', 'CONNECTION_TYPE', 'BILL_CYC_CD',
    'LAT', 'LON', 'SERIAL_NBR', 'METER_READ_REMARK', 'LAST_BILL_DATE',
    'BILL_BASIS', 'PAY_AMT', 'PAY_DATE', 'TOTAL_OUTSTANDING', 'SUBSTATION', 'FEEDER',
    'MOBILE_NO',
    'CURRENT_ASSESSMENT', 'CROSS_SUBS', 'PTW_SUBS', 'TARIFF_SUBS',
    'POWERLOOM_SUBS', 'WMCR_SUBS', 'CONSUMPTION_CURR_MNTH'
]
MAX_BYTES = 5 * 1024 * 1024  # 5 MB per chunk

# ─── GLOBALS ─────────────────────────────────────────────────────────────────
SYNC_LOG   = []
IS_RUNNING = False


def log(msg):
    global SYNC_LOG
    t = datetime.now().strftime('%H:%M:%S')
    m = f"[{t}] {msg}"
    print(m, flush=True)
    SYNC_LOG.append(m)
    if len(SYNC_LOG) > 500:
        SYNC_LOG.pop(0)


# ─── GITHUB HELPERS ──────────────────────────────────────────────────────────
def _gh_headers(pat):
    return {'Authorization': f'token {pat}', 'Accept': 'application/vnd.github+json'}


def gh_get_json(path):
    url = f'https://raw.githubusercontent.com/{GH_OWNER}/{GH_REPO}/main/{path}'
    r = requests.get(url, timeout=15)
    if r.status_code == 200:
        return r.json()
    return None


def gh_put(path, content_str, pat, message='FTP sync'):
    url = f'https://api.github.com/repos/{GH_OWNER}/{GH_REPO}/contents/{path}'
    headers = _gh_headers(pat)
    sha = None
    r = requests.get(url, headers=headers, timeout=15)
    if r.status_code == 200:
        sha = r.json().get('sha')
    body = {
        'message': message,
        'content': base64.b64encode(content_str.encode('utf-8')).decode('ascii'),
        'branch':  GH_BRANCH
    }
    if sha:
        body['sha'] = sha
    r = requests.put(url, headers=headers, json=body, timeout=60)
    if r.status_code not in (200, 201):
        raise RuntimeError(f"GitHub {r.status_code}: {r.text[:200]}")
    return r.json()


def fetch_discoms():
    # Local config takes priority (credentials stay private)
    local = CONFIG.get('discoms', [])
    if local:
        return local
    # Fallback: public discoms.json on GitHub (no passwords there)
    d = gh_get_json('discoms.json')
    return d if d else []


def fetch_manifest():
    m = gh_get_json('manifest.json')
    if not m:
        m = {'DV': {}, 'MV': {}, 'PV': {}, 'PU': {}}
    return m


# ─── FTP HELPERS ─────────────────────────────────────────────────────────────
def ftp_connect(d):
    ftp = FTP()
    ftp.connect(d.get('ftpServer', 'ftp.uppclonline.com'), int(d.get('ftpPort', 21)), timeout=60)
    ftp.login(user=d['ftpUser'], passwd=d['ftpPass'])
    return ftp


def ftp_list(ftp, path):
    try:
        entries = ftp.nlst(path)
        return [e.split('/')[-1] for e in entries if e]
    except error_perm:
        return []


def ftp_download_gz(ftp, remote_path):
    buf = io.BytesIO()
    ftp.retrbinary('RETR ' + remote_path, buf.write)
    buf.seek(0)
    return gzip.decompress(buf.read())


_MONTH_ORDER = {'JAN':1,'FEB':2,'MAR':3,'APR':4,'MAY':5,'JUN':6,
                'JUL':7,'AUG':8,'SEP':9,'OCT':10,'NOV':11,'DEC':12}

def _month_dir_key(d):
    parts = d.upper().split('_')
    if len(parts) >= 2 and parts[1].isdigit():
        return (int(parts[1]), _MONTH_ORDER.get(parts[0], 0))
    return (0, 0)


def find_master_file(ftp, code_num):
    month_dirs = ftp_list(ftp, FTP_MASTER)
    month_dirs = [d for d in month_dirs if d and '_' in d]
    if not month_dirs:
        raise FileNotFoundError(f'No month folders in {FTP_MASTER}')
    latest = sorted(month_dirs, key=_month_dir_key)[-1]
    folder = f'{FTP_MASTER}/{latest}'
    files = ftp_list(ftp, folder)
    for fname in files:
        if f'DIV{code_num}_' in fname.upper() and fname.upper().endswith('.CSV.GZ'):
            return f'{folder}/{fname}', latest
    raise FileNotFoundError(f'No master file for DIV{code_num} in {folder}')


def find_daily_file(ftp, base_folder, prefix, code_num):
    now = datetime.utcnow()
    for delta in (0, 1):
        d = now - timedelta(days=delta)
        ddmmyyyy = d.strftime('%d%m%Y')
        folder = f'{base_folder}/{ddmmyyyy}'
        files = ftp_list(ftp, folder)
        for fname in files:
            if (fname.upper().startswith(prefix.upper())
                    and f'DIV{code_num}_' in fname.upper()
                    and fname.upper().endswith('.CSV.GZ')):
                return f'{folder}/{fname}', ddmmyyyy
    raise FileNotFoundError(f'No {prefix}*DIV{code_num}* file in {base_folder} (today/yesterday)')


# ─── DATA PROCESSING ─────────────────────────────────────────────────────────
def _find_col(hdrs, options):
    for opt in options:
        try:
            return hdrs.index(opt.upper())
        except ValueError:
            continue
    return -1


def _find_col_fuzzy(hdrs, options):
    """Exact match first; if none, look for any header containing one of the
    tokens as a standalone word (e.g. 'GPS LAT', 'CONSUMER_LATITUDE')."""
    idx = _find_col(hdrs, options)
    if idx >= 0:
        return idx
    pattern = re.compile(r'\b(' + '|'.join(options) + r')\b')
    for i, h in enumerate(hdrs):
        if pattern.search(h):
            return i
    return -1


def _csv_escape(v):
    v = str(v) if v is not None else ''
    if any(c in v for c in (',', '"', '\n')):
        v = '"' + v.replace('"', '""') + '"'
    return v


ALLOWED_CON_STATUS = {'IN SERVICE', 'TD', 'TD >6 MONTHS'}


def shard_master(rows, discom_id, div_code):
    if not rows:
        return []
    keys = list(rows[0].keys())
    hdrs = [k.strip().upper() for k in keys]

    i_acct     = _find_col(hdrs, ['ACCT_ID', 'ACCOUNT_ID'])
    i_sdo      = _find_col(hdrs, ['SDO_CODE', 'SDO'])
    i_name     = _find_col(hdrs, ['NAME', 'CONSUMER_NAME'])
    i_fath     = _find_col(hdrs, ['FATHER_NAME', 'FATHER', 'FNAME', 'F_NAME'])
    i_addr     = _find_col(hdrs, ['ADDRESS', 'ADDRES'])
    i_supply   = _find_col(hdrs, ['SUPPLY_TYPE', 'CATEGORY', 'TARIFF_TYPE', 'TARIFF'])
    i_load     = _find_col(hdrs, ['LOAD', 'SANCTION_LOAD', 'SANCT_LOAD'])
    i_lunit    = _find_col(hdrs, ['LOAD_UNIT', 'LOAD UNIT'])
    i_con_stat = _find_col(hdrs, ['CON_STATUS', 'CONNECTION_STATUS', 'CONS_STATUS'])
    i_con_type = _find_col(hdrs, ['CONNECTION_TYPE', 'CONN_TYPE', 'CON_TYPE'])
    i_bill_cyc = _find_col(hdrs, ['BILL_CYC_CD', 'BILL_CYC', 'BILLING_CYCLE'])
    i_lat      = _find_col_fuzzy(hdrs, ['LAT', 'LATITUDE', 'GPS_LAT', 'Y_COORD'])
    i_lon      = _find_col_fuzzy(hdrs, ['LON', 'LONG', 'LONGITUDE', 'LNG', 'GPS_LON', 'GPS_LONG', 'X_COORD'])
    if i_lat < 0 or i_lon < 0:
        log(f'  ⚠ master: LAT/LON column not found in source headers: {hdrs}')
    i_serl     = _find_col(hdrs, ['SERIAL_NBR', 'SERIAL_NO', 'METER_NO', 'MTR_SRL_NO', 'SERIAL'])
    i_remark   = _find_col(hdrs, ['METER_READ_REMARK', 'MR_REMARK', 'REMARK'])
    i_lbill    = _find_col(hdrs, ['LAST_BILL_DATE', 'BILL_DATE', 'LAST BILL DATE'])
    i_bbasis   = _find_col(hdrs, ['BILL_BASIS', 'BILLING_BASIS'])
    i_amt      = _find_col(hdrs, ['PAY_AMT', 'LP AMT', 'LAST_PAY_AMT'])
    i_date     = _find_col(hdrs, ['PAY_DATE', 'LP DATE', 'LAST_PAY_DATE'])
    i_out      = _find_col(hdrs, ['TOTAL_OUTSTANDING', 'TOTAL OUTSTANDING', 'AMOUNT_PAYABLE'])
    i_sub      = _find_col(hdrs, ['SUBSTATION', 'SUB_STATION'])
    i_feed     = _find_col(hdrs, ['FEEDER'])
    i_mob      = _find_col(hdrs, ['MOBILE_NO', 'MOBILE'])

    # Commercial-summary columns (Commercial tab: division/SDO/substation/feeder rollups)
    i_cur_assess = _find_col(hdrs, ['CURRENT_ASSESSMENT', 'CUR_ASSESSMENT', 'CURRENT_ASSESSMENT_AMT'])
    i_cross_sub  = _find_col(hdrs, ['CROSS_SUBSIDY', 'CROSS_SUBS'])
    i_ptw_sub    = _find_col(hdrs, ['PTW_SUBSIDY', 'PTW_SUBS'])
    i_tariff_sub = _find_col(hdrs, ['TARIFF_SUBSIDY', 'TARIFF_SUBS'])
    i_pwrloom    = _find_col(hdrs, ['POWERLOOM_SUBS', 'POWERLOOM_SUBSIDY'])
    i_wmcr       = _find_col(hdrs, ['WMCR_SUBS', 'WMCR_SUBSIDY'])
    i_consump    = _find_col(hdrs, ['CONSUMPTION_CURR_MNTH', 'CONSUMPTION_CURRENT_MONTH'])
    # Components used only to fix a negative CURRENT_ASSESSMENT (never stored themselves)
    i_ec         = _find_col(hdrs, ['EC'])
    i_fc         = _find_col(hdrs, ['FC'])
    i_demand_amt = _find_col(hdrs, ['DEMAND_AMT'])
    i_elec_duty  = _find_col(hdrs, ['ELECTRICITY_DUTY'])
    if i_cur_assess < 0 or i_cross_sub < 0 or i_ptw_sub < 0 or i_tariff_sub < 0 \
       or i_pwrloom < 0 or i_wmcr < 0 or i_consump < 0:
        log(f'  ⚠ master: one or more commercial columns not found in source headers: {hdrs}')

    def _cell(vals, idx):
        return str(vals[idx]).strip() if idx >= 0 and idx < len(vals) else ''

    def _num(vals, idx):
        raw = _cell(vals, idx)
        try:
            return float(raw)
        except (TypeError, ValueError):
            return 0.0

    header_line = ','.join(CSV_COLS) + '\n'
    files = []
    chunk_lines = []
    chunk_size  = len(header_line)
    letter      = 0

    def flush():
        nonlocal chunk_lines, chunk_size, letter
        if not chunk_lines:
            return
        fname   = f'{discom_id}/{div_code}/master/chunk_{chr(97 + letter)}.csv'
        content = header_line + ''.join(chunk_lines)
        files.append((fname, content))
        letter += 1
        chunk_lines, chunk_size = [], len(header_line)

    with_coords = 0
    for r in rows:
        vals = [r.get(k, '') for k in keys]

        # CON_STATUS filter — only keep In Service, TD, TD >6 MONTHS rows
        con_stat_val = _cell(vals, i_con_stat).upper()
        if i_con_stat >= 0 and con_stat_val not in ALLOWED_CON_STATUS:
            continue

        lat = _cell(vals, i_lat)
        lon = _cell(vals, i_lon)
        try:
            if float(lat) > 50:
                lat, lon = lon, lat
        except (TypeError, ValueError):
            pass
        if lat and lon:
            with_coords += 1

        # Replicate FixNegativeCurrentAssessment: a negative CURRENT_ASSESSMENT is
        # replaced by EC+FC+DEMAND_AMT+ELECTRICITY_DUTY (the workbook's own repair rule)
        cur_assess = _num(vals, i_cur_assess)
        if cur_assess < 0:
            cur_assess = (_num(vals, i_ec) + _num(vals, i_fc)
                          + _num(vals, i_demand_amt) + _num(vals, i_elec_duty))

        mapped = {
            'ACCT_ID':           _cell(vals, i_acct),
            'SDO_CODE':          _cell(vals, i_sdo),
            'NAME':              _cell(vals, i_name),
            'FATHER_NAME':       _cell(vals, i_fath),
            'ADDRESS':           _cell(vals, i_addr),
            'SUPPLY_TYPE':       _cell(vals, i_supply),
            'LOAD':              _cell(vals, i_load),
            'LOAD_UNIT':         _cell(vals, i_lunit),
            'CON_STATUS':        con_stat_val,
            'CONNECTION_TYPE':   _cell(vals, i_con_type),
            'BILL_CYC_CD':       _cell(vals, i_bill_cyc),
            'LAT':               lat,
            'LON':               lon,
            'SERIAL_NBR':        _cell(vals, i_serl),
            'METER_READ_REMARK': _cell(vals, i_remark),
            'LAST_BILL_DATE':    _cell(vals, i_lbill),
            'BILL_BASIS':        _cell(vals, i_bbasis),
            'PAY_AMT':           _cell(vals, i_amt),
            'PAY_DATE':          _cell(vals, i_date),
            'TOTAL_OUTSTANDING': _cell(vals, i_out),
            'SUBSTATION':        _cell(vals, i_sub),
            'FEEDER':            _cell(vals, i_feed),
            'MOBILE_NO':         _cell(vals, i_mob),
            'CURRENT_ASSESSMENT':    str(cur_assess),
            'CROSS_SUBS':            _cell(vals, i_cross_sub),
            'PTW_SUBS':              _cell(vals, i_ptw_sub),
            'TARIFF_SUBS':           _cell(vals, i_tariff_sub),
            'POWERLOOM_SUBS':        _cell(vals, i_pwrloom),
            'WMCR_SUBS':             _cell(vals, i_wmcr),
            'CONSUMPTION_CURR_MNTH': _cell(vals, i_consump),
        }
        line = ','.join(_csv_escape(mapped[c]) for c in CSV_COLS) + '\n'
        if chunk_size + len(line) > MAX_BYTES:
            flush()
        chunk_lines.append(line)
        chunk_size += len(line)
    flush()
    log(f'  master: {with_coords}/{len(rows)} rows had LAT/LON coordinates')
    return files


def chunk_passthrough(raw_bytes, discom_id, div_code, f_type):
    text  = raw_bytes.decode('utf-8', errors='replace')
    lines = text.splitlines(keepends=True)
    if not lines:
        return []
    header = lines[0]
    files  = []
    chunk_lines = []
    chunk_size  = len(header)
    letter      = 0

    def flush():
        nonlocal chunk_lines, chunk_size, letter
        if not chunk_lines:
            return
        fname   = f'{discom_id}/{div_code}/{f_type}/chunk_{chr(97 + letter)}.csv'
        content = header + ''.join(chunk_lines)
        files.append((fname, content))
        letter += 1
        chunk_lines, chunk_size = [], len(header)

    for line in lines[1:]:
        if chunk_size + len(line) > MAX_BYTES:
            flush()
        chunk_lines.append(line)
        chunk_size += len(line)
    flush()
    return files


# ─── DISCOVERY ───────────────────────────────────────────────────────────────
def run_discovery(pat):
    global IS_RUNNING
    IS_RUNNING = True
    try:
        log('Starting Division Discovery across all DISCOMs...')
        discoms  = fetch_discoms()
        manifest = fetch_manifest()

        for d in discoms:
            d_id = d['id']
            if not isinstance(manifest.get(d_id), dict):
                manifest[d_id] = {}
            if 'ftpPass' not in d:
                log(f'  Skipping {d_id}: no FTP credentials in config.json')
                continue
            try:
                log(f"  [{d_id}] Connecting as {d['ftpUser']}...")
                ftp = ftp_connect(d)
                month_dirs = ftp_list(ftp, FTP_MASTER)
                month_dirs = [x for x in month_dirs if x and '_' in x]
                if not month_dirs:
                    log(f'  [{d_id}] No month folders found')
                    ftp.quit()
                    continue
                latest = sorted(month_dirs)[-1]
                log(f'  [{d_id}] Scanning {FTP_MASTER}/{latest}...')
                files = ftp_list(ftp, f'{FTP_MASTER}/{latest}')
                found = 0
                for fname in files:
                    if not fname.upper().endswith('.CSV.GZ'):
                        continue
                    parts = fname.split('_')
                    if len(parts) < 2 or not parts[1].upper().startswith('DIV'):
                        continue
                    div_code = parts[1].upper()
                    if div_code not in manifest[d_id]:
                        manifest[d_id][div_code] = {'master': [], 'billed': [], 'unbilled': []}
                        log(f'    + {d_id}/{div_code}')
                        found += 1
                    else:
                        log(f'    = {d_id}/{div_code} (already known)')
                if not found:
                    log(f'  [{d_id}] No new divisions found')
                ftp.quit()
            except Exception as e:
                log(f'  [{d_id}] Error: {e}')

        manifest['updated'] = datetime.utcnow().isoformat() + 'Z'
        log('Uploading manifest.json to GitHub...')
        gh_put('manifest.json', json.dumps(manifest, indent=2), pat, 'Discovery: register divisions')
        log('✓ Discovery complete.')
    except Exception as e:
        log(f'CRITICAL: {e}')
    finally:
        IS_RUNNING = False


# ─── SYNC ────────────────────────────────────────────────────────────────────
def run_sync(types, pat, target_discom=None, target_division=None, force=False):
    global IS_RUNNING
    IS_RUNNING = True
    try:
        log(f"Sync | types={types} | discom={target_discom} | div={target_division} | force={force}")
        discoms  = fetch_discoms()
        manifest = fetch_manifest()
        uploads  = []

        today_str     = datetime.utcnow().strftime('%d%m%Y')
        yesterday_str = (datetime.utcnow() - timedelta(days=1)).strftime('%d%m%Y')

        for d in discoms:
            if target_discom and d['id'] != target_discom:
                continue
            d_id = d['id']
            if 'ftpPass' not in d:
                log(f'Skipping {d_id}: no FTP credentials in config.json')
                continue
            if not isinstance(manifest.get(d_id), dict):
                manifest[d_id] = {}

            divs = [target_division] if target_division else list(manifest[d_id].keys())
            if not divs:
                log(f'No divisions for {d_id} — run Discovery first')
                continue

            # Determine which divisions actually need FTP work
            needs_ftp = []
            for div_code in divs:
                if div_code not in manifest[d_id]:
                    manifest[d_id][div_code] = {'master': [], 'billed': [], 'unbilled': []}
                entry = manifest[d_id][div_code]
                ss    = entry.get('sync_status', {})
                need  = []
                if 'master' in types:
                    # Always attempt master — let FTP determine if a newer month is available
                    need.append('master')
                if 'billed' in types:
                    existing = ss.get('billed_date', '')
                    if force or not entry.get('billed') or existing not in (today_str, yesterday_str):
                        need.append('billed')
                    else:
                        log(f'  [{d_id}/{div_code}] billed already uploaded ({existing}), skipping')
                if 'unbilled' in types:
                    existing = ss.get('unbilled_date', '')
                    if force or not entry.get('unbilled') or existing not in (today_str, yesterday_str):
                        need.append('unbilled')
                    else:
                        log(f'  [{d_id}/{div_code}] unbilled already uploaded ({existing}), skipping')
                if need:
                    needs_ftp.append((div_code, need))

            if not needs_ftp:
                log(f'[{d_id}] All selected data already uploaded. Use FORCE to re-sync.')
                continue

            try:
                log(f"[{d_id}] Connecting as {d['ftpUser']}...")
                ftp = ftp_connect(d)

                for div_code, need in needs_ftp:
                    code_num = div_code.upper().replace('DIV', '')
                    entry = manifest[d_id][div_code]

                    if 'master' in need:
                        try:
                            ftp_path, month_dir = find_master_file(ftp, code_num)
                            synced_period = entry.get('sync_status', {}).get('master_period', '')
                            if not force and synced_period == month_dir and entry.get('master'):
                                log(f'  [{d_id}/{div_code}] master already current ({month_dir}), skipping')
                            else:
                                if synced_period and synced_period != month_dir:
                                    log(f'  [{d_id}/{div_code}] New master period: {synced_period} → {month_dir}')
                                log(f'  [{d_id}/{div_code}] Downloading master...')
                                raw  = ftp_download_gz(ftp, ftp_path)
                                rows = list(csv.DictReader(io.StringIO(raw.decode('utf-8', 'replace'))))
                                log(f'  master: {len(rows)} rows')
                                files = shard_master(rows, d_id, div_code)
                                uploads.extend(files)
                                entry['master'] = [f for f, _ in files]
                                entry.setdefault('sync_status', {})['master_period'] = month_dir
                                log(f'  master → {len(files)} chunk(s)')
                        except FileNotFoundError as e:
                            log(f'  master skipped: {e}')

                    if 'billed' in need:
                        try:
                            ftp_path, ddmmyyyy = find_daily_file(ftp, FTP_BILLED, 'BILLED_', code_num)
                            log(f'  [{d_id}/{div_code}] Downloading billed...')
                            raw   = ftp_download_gz(ftp, ftp_path)
                            files = chunk_passthrough(raw, d_id, div_code, 'billed')
                            uploads.extend(files)
                            entry['billed'] = [f for f, _ in files]
                            entry.setdefault('sync_status', {})['billed_date'] = ddmmyyyy
                            log(f'  billed → {len(files)} chunk(s)')
                        except FileNotFoundError as e:
                            log(f'  billed skipped: {e}')

                    if 'unbilled' in need:
                        try:
                            ftp_path, ddmmyyyy = find_daily_file(ftp, FTP_UNBILLED, 'UNBILLED_', code_num)
                            log(f'  [{d_id}/{div_code}] Downloading unbilled...')
                            raw   = ftp_download_gz(ftp, ftp_path)
                            files = chunk_passthrough(raw, d_id, div_code, 'unbilled')
                            uploads.extend(files)
                            entry['unbilled'] = [f for f, _ in files]
                            entry.setdefault('sync_status', {})['unbilled_date'] = ddmmyyyy
                            log(f'  unbilled → {len(files)} chunk(s)')
                        except FileNotFoundError as e:
                            log(f'  unbilled skipped: {e}')

                    entry['updated'] = datetime.utcnow().isoformat() + 'Z'
                    log(f'  [{d_id}/{div_code}] Done')

                ftp.quit()
            except Exception as e:
                log(f'[{d_id}] Error: {e}')

        if not uploads:
            log('Nothing to upload (all selected data already current).')
            return

        manifest['updated'] = datetime.utcnow().isoformat() + 'Z'
        uploads.append(('manifest.json', json.dumps(manifest, indent=2)))
        log(f'Uploading {len(uploads)} file(s) to GitHub...')
        for path, content in uploads:
            log(f'  → {path}')
            gh_put(path, content, pat, f'FTP sync: {path}')
        log('✓ DONE. All files uploaded.')
    except Exception as e:
        log(f'CRITICAL: {e}')
    finally:
        IS_RUNNING = False


# ─── ENDPOINTS ───────────────────────────────────────────────────────────────
@app.route('/ping')
def ping():
    return jsonify({'ok': True})


@app.route('/status')
def status():
    return jsonify({'running': IS_RUNNING, 'log': SYNC_LOG})


@app.route('/discover', methods=['POST'])
def discover():
    if IS_RUNNING:
        return jsonify({'ok': False, 'message': 'Already running'})
    data = request.json or {}
    pat  = data.get('pat')
    if not pat:
        return jsonify({'ok': False, 'message': 'GitHub PAT required'})
    threading.Thread(target=run_discovery, args=(pat,), daemon=True).start()
    return jsonify({'ok': True, 'message': 'Discovery started'})


@app.route('/sync-status')
def sync_status():
    """Return what data is already uploaded, keyed by division number (without DIV prefix)."""
    try:
        manifest = fetch_manifest()
        result = {}
        for dc_id, dc_val in manifest.items():
            if not isinstance(dc_val, dict):
                continue
            for div_code, div_val in dc_val.items():
                if not isinstance(div_val, dict):
                    continue
                ss = div_val.get('sync_status', {})
                if ss:
                    num = div_code.upper().replace('DIV', '')
                    result[num] = ss
        return jsonify({'ok': True, 'sync_status': result})
    except Exception as e:
        return jsonify({'ok': False, 'sync_status': {}, 'error': str(e)})


@app.route('/sync', methods=['POST'])
def sync():
    if IS_RUNNING:
        return jsonify({'ok': False, 'message': 'Sync already in progress'})
    data = request.json or {}
    pat  = data.get('pat')
    if not pat:
        return jsonify({'ok': False, 'message': 'GitHub PAT required'})
    threading.Thread(
        target=run_sync,
        kwargs={
            'types':           data.get('types', ['master', 'billed', 'unbilled']),
            'pat':             pat,
            'target_discom':   data.get('discom'),
            'target_division': data.get('division'),
            'force':           bool(data.get('force', False)),
        },
        daemon=True
    ).start()
    return jsonify({'ok': True, 'message': 'Sync started'})


if __name__ == '__main__':
    log('=' * 50)
    log('UPPCL Local Server  —  port 7321')
    log('Keep this window open while using the web app.')
    log('Press Ctrl+C to stop.')
    log('=' * 50)
    if not CONFIG.get('discoms'):
        log('WARNING: config.json not found or has no discoms — FTP operations will fail.')
        log('         Copy config.json into the same folder as local_server.py.')
    app.run(host='127.0.0.1', port=7321, debug=False)
