@echo off
title UPPCL Local Server
color 0A

echo ============================================================
echo   UPPCL DATA SERVER  -  Starting on port 7321
echo ============================================================
echo.

REM Check Python is available
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Install Python 3.8+ from python.org
    pause
    exit /b 1
)

REM Install / upgrade dependencies quietly
echo Installing dependencies...
pip install flask flask-cors requests -q --disable-pip-version-check
echo Dependencies OK.
echo.

REM Check config.json exists
if not exist "%~dp0config.json" (
    echo ERROR: config.json not found in this folder.
    echo        Make sure config.json is in the same folder as this script.
    pause
    exit /b 1
)

echo Starting server...
echo If Windows Firewall asks, click "Allow access" (Private networks).
echo.

python "%~dp0local_server.py"

echo.
echo Server stopped.
pause
